# Tradewater Channel Map

A go-to-market tool mapping the intermediaries that can sell Tradewater's refrigerant (ODS destruction) and orphaned-well methane credits: marketplaces, procurement platforms, brokers, consumer platforms, exchanges, offtakers, recommenders and convenings.

Each channel is tagged by status:

- **Partner**: existing Tradewater relationship
- **Competitor-supplied**: already carries refrigerant or well credits from another developer
- **Open lane**: relevant buyer reach, no evidence of these credit types yet

## What's in the repo

| File | Purpose |
|---|---|
| `index.html` | The interactive map. Self-contained, no build step. |
| `data/channels.json` | Channel data (same records the page uses) for scripts or a future pipeline. |
| `data/channels.csv` | Same data as a spreadsheet. |

## Features

- **Type × status matrix**: click any channel to jump to its record
- **Filters** by status and by credit line (refrigerant / orphan wells), sorted by fit
- **Per-channel record**: what they do, evidence, pitch angle, next step, sources
- **Outreach stage tracker** saved in the browser (localStorage)
- **Copy as CSV** with current outreach stages

## Run it

Open `index.html` in a browser, or publish with GitHub Pages:

1. Push this folder to a GitHub repo.
2. Settings → Pages → Source: *Deploy from a branch* → `main` / root.
3. The site is live at `https://<user>.github.io/<repo>/`.

## Updating the data

Channel records live in the `D` array inside `index.html`'s script. To add a channel, add an object with:

```js
{ id, name, type, status: "partner" | "comp" | "open", lines: ["ODS", "Wells"],
  fit: 1-5, what, evidence, angle, next, src: [["label", "url"], ...] }
```

Then update `data/channels.json` and `data/channels.csv` to match.

## Notes

- Fit scores are a first-pass judgment (buyer reach, product fit, ease of entry), not measured data.
- Research as of October 2026. Verify current listings and CORSIA eligibility of specific vintages before outreach.

## Next build ideas

- Load records from `data/channels.json` instead of the inline array
- Pull new retirements from the Berkeley Voluntary Registry Offsets Database to flag intermediaries retiring ODS or well credits on behalf of clients
- Sync outreach stages to a shared store (Sheet or HubSpot) instead of localStorage
